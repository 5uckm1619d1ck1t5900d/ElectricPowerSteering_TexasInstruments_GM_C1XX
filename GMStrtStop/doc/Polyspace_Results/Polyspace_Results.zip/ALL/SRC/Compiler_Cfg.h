/*****************************************************************************
* Copyright 2014 Nexteer Automotive, All Rights Reserved.
* Nexteer Confidential
*
* Module File Name  : Compiler_Cfg.h
* Module Description: This file contains a stub header for UTP and QAC 
*                     projects
* Product           : Gen II Plus EA3.0
* Author            : Jared Julien
*****************************************************************************/
/*---------------------------------------------------------------------------
* Version Control:
* Date Created:      Thr May 8 12:17:00 2014
* %version:          1 %
* %derived_by:       kzdyfh %
* %date_modified:    Fri Aug 23 15:04:36 2013 %
*---------------------------------------------------------------------------*/
#ifndef COMPILER_CFG_H
#define COMPILER_CFG_H



#endif  /* COMPILER_CFG_H */
