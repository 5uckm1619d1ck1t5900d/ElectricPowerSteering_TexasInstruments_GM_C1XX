#ifndef AP_TRQARBLIM_CFG_H
#define AP_TRQARBLIM_CFG_H

        extern void Rte_Call_TrqArblim_Per1_CP0_CheckpointReached(void);
        extern void Rte_Call_TrqArblim_Per1_CP1_CheckpointReached(void);


#endif 
