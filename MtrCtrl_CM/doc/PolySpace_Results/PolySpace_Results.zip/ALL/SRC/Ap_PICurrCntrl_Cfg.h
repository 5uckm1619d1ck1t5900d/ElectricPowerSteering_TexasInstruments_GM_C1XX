#ifndef AP_PICURRCNTRL_CFG_H
#define AP_PICURRCNTRL_CFG_H

        extern void Rte_Call_PICurrCntrl_Per2_CP0_CheckpointReached(void);
        extern void Rte_Call_PICurrCntrl_Per2_CP1_CheckpointReached(void);


#endif 

